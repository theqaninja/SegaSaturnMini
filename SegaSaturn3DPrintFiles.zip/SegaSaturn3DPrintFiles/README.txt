Have person printing these files visit this URL Link to get exact instructions and dimensions when printing these files out. 

https://www.thingiverse.com/thing:3089752/files

Check out 8Bit Flashback's other awesome work on this site and visit his Youtube channel. 